<?php
function acmt_get_ebib()
{
    if(!is_user_logged_in()) {
        wp_redirect(site_url('race'));
    }

    $current_user = wp_get_current_user();
    $email = $current_user->user_email;

    $isRequestEmail = isset($_GET['se']) ? 1 : 0;

        $data = array(
            'email' => $email,
            'name' => $current_user->first_name,
            'isRequestEmail' => $isRequestEmail
        );

        $curl = curl_init();
        // Local machine url
        // $url = 'http://5.101.138.142:8980/api/barcode';

        // Live Server url
        $url = 'http://192.168.1.142:8980/api/barcode';

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_FOLLOWLOCATION => 1,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
            ]
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            ob_clean();
            header('Content-type: application/pdf');
            echo $response;
            exit;
        }
}
add_shortcode('acmt_ebib', 'acmt_get_ebib');