<?php
/**
 * Plugin Name: Access Bank Marathon
 * Description: e-Bib generation for Lagos City Marathon organized by Access Bank plc.
 * 
 */

/// Test function to submit form

function serializeMetaArray(&$arr)
{
    return serialize($arr);

    // height;100,weight;50,phone;08034206970
}

function deserializeMetaArray($str)
{


    if (is_serialized($str)){
        return unserialize($str);
    }

    return [];
}

function registration_form_validation($email,$first_name,$last_name,$password) {
    global $reg_errors;
    $reg_errors = new WP_Error;
    if ( empty( $first_name ) || empty( $password ) || empty( $email ) || empty( $last_name ) ) {
        $reg_errors->add('field', 'Required form field is missing');
    }
    if ( empty( $first_name ) || empty( $password ) || empty( $email ) ) {
        $reg_errors->add('field', 'Required form field is missing');
    }
    if ( !is_email( $email ) ) {
        $reg_errors->add( 'email_invalid', 'Email is not valid' );
    }
    if ( email_exists( $email ) ) {
        $reg_errors->add( 'email', 'Email Already in use' );
    }
    if ( is_wp_error( $reg_errors ) ) {
 
        foreach ( $reg_errors->get_error_messages() as $error ) {
         
            echo '<div>';
            echo '<strong>ERROR</strong>:';
            echo $error . '<br/>';
            echo '</div>';
             
        }
     
    }
}

// PIncludes
include('acmt_transactions.php');

include('acmt_submit_form1.php');

include('acmt_submit_form2.php');

include('acmt_get_ebib.php');

include('acmt_group_register.php');

include('acmt_registered_users_process.php');

include('acmt_select_participant.php');

// include('acmt_payment_receipt.php');


function accessbank_menu_option()
{
    // add_menu_page('Title of Function Page', 'Menu name', 'User access role', 'slog', 'callback function', 'image-icon', 200);

    add_menu_page('Header & Footer Script', 'Access Marathon', 'manage_options', 'accessbank-admin-menu', 'accessbank_scripts_page', '', 200);
}

add_action('admin_menu', 'accessbank_menu_option');

function accessbank_scripts_page()
{
    include('templates/accessbank_admin.php');
}

// Adding Bootstrap Validation for form validation


function wpb_adding_scripts() {
 
        wp_register_script('custom_script', plugins_url('js/custom_script.js', __FILE__), array('jquery'),'1.1', true);
         
        wp_enqueue_script('custom_script');
          
    //     add_action( 'wp_enqueue_scripts', 'wpb_adding_scripts' ); 

    // wp_register_script('bootstrap_select_script', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js');
    // wp_enqueue_script('bootstrap_select_script'); 

    // wp_register_style('bootstrap_select_style', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css');
    // wp_enqueue_style('bootstrap_select_style'); 
} 
add_action( 'wp_enqueue_scripts', 'wpb_adding_scripts' );  // End of Javascript
/*
*   Woocommerce account page menu editing
*/

include('woocommerce/my-account.php');
?> 