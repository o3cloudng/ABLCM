
var checker = document.getElementById('agree');
var sendbtn = document.getElementById('submit');
checker.onchange = function() {
  sendbtn.disabled = !this.checked;
};
