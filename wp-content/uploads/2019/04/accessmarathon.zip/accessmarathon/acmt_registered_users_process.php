<?php

function acmt_registered_users_shortcode()
{
    ?>
    <h1>Admin Page for all users</h1>
    <table class="table table-bordered table-stripped table-condensed table-collapse">
     <tr>
         <th>SN</th><th>Display Name</th> <th>Email</th> <th>Payment Status</th> <th>Race</th> <th>E_BIB</th> <th>View | Edit | Delete</th>
     </tr>
    <?php
    // if(!is_admin()) {
    //     wp_redirect(site_url('race'));
    // }

        global $wpdb;
        $users = $wpdb->get_results( "SELECT * FROM wp_users" );
        $users_array = json_decode(json_encode($users),true);
        
        foreach($users_array as $user){
    ?>

     <tr>
         <td>
             <?php echo $user['display_name']; ?>
        </td>
        <td><?php echo $user['email']; ?></td>
        <td>5,000.00</td>
        <td><?php echo $user['display_name']; ?></td>
        <td><?php echo $user['display_name']; ?></td>
        <td><?php echo $user['display_name']; ?></td>
        <td>
            <a href="#" class="text-warning"><i class="fa fa-eye-slash"></i></a>
            <a href="#" class="text-primary"><i class="fa fa-edit"></i></a>
            <a href="#" class="text-danger"><i class="fa fa-times"></i></a>
        </td>
     
 

<?php
    } ?>
    </tr>
 </table>
<?php 
}
add_shortcode('acmt_registered_users_shortcode', 'acmt_registered_users_shortcode');




?>