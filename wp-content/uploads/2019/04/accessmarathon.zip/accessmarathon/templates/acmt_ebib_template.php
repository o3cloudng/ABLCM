<div class="row">
       <div class="container" style="height:400px;">
           <div class="col-xs-12 col-sm-12 col-md-10 offset-md-1">
           <div class="card text-center">
                <div class="card-header">
                    <img src="http://localhost/access-marathon/wp-content/uploads/2019/03/Access-Bank-Logo.png" alt="" style="width:50%;" class="img-responsive">
                </div>
                <div class="card-body text-middle" style="height:150px; margin:auto">
                    <h1 style="font-size:800%; font-weight:bold;">15993</h1>
                </div>
                <div class="card-footer text-left p-0" style="background:darkblue;">
                    <img src="http://localhost/access-marathon/wp-content/uploads/2019/03/bib-footer.png" style="width:50%;" alt="" class="img-responsive ml-4">
                </div>
                </div>
           </div>
           <?php //echo $_SERVER['REMOTE_ADDR']."".$_SERVER['REQUEST_URI']; ?>
       </div>
   </div>
