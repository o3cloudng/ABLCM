<!-- <h2>Registration Form</h2> -->
<div class="container">
    <div class="container">
        <div class="col-8 offset-2">
        <style>
        #select {
            font-size: 14px;
        }
    </style>
        <img src="<?php echo site_url(); ?>/wp-content/uploads/form3.png" class="center my-5"/>
        <h2>Payment</h2>
        <p>Complete your registration by making payment.</p>
        <!-- <p>&nbsp;</p> -->
                        
                    <form method="post" action="">
                        <div class="card-body">
                            <!-- <div>
                                <div class="form-group">
                                <label>Family Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Family Name" value="<?php ( isset( $_POST['name'] ) ? $name : null ) ?>">
                            </div>
                            <div class="form-group">
                                    <label>Given Name</label>
                                    <input type="text" class="form-control" name="username" placeholder="Preferred Name"  value="<?php ( isset( $_POST['username'] ) ? $username : null ) ?>">
                            </div> -->
                            <div class="form-group">
                                <div class=" my-4">
                                    <label>Select race</label>
                                    <select id="select" name="race" class="custom-select custom-select-lg">
                                        <option value="42km">42km</option>
                                        <option value="10km">10km</option>
                                    </select>                                    
                                </div> 
                            </div>
                            <div class="form-group">
                                <label>Select appropriate amount in currency</label>
                                <select name="amount" id="select" class="custom-select custom-select-lg">
                                    <option value="5000">NGN 5000</option>
                                    <!-- <option value="200">$200</option> -->
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="acmt_payment" class="btn btn-primary btn-block" value="Complete Registration" />
                            </div>
                            
                        </div>
                    </div>
                </div>
                      
            
        
        </div>
        <div class="container mt-5">
            <img src="http://localhost/access-marathon/wp-content/uploads/2019/03/sponsors.jpg" alt="" style="width:100%;">
        </div>
