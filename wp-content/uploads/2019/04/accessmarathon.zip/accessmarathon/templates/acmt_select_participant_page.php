<div class="container">
    <div class="row my-5">
        <div class="col-md-4">
            <a href="<?php echo site_url('/race'); ?>" class="card bg-primary text-white text-center">
                <!-- <img class="card-img-top" src="..." alt="Card image cap">  -->
                <i class="fa fa-5x fa-user text-center py-5"></i>
                <div class="card-header">Single Participant</div>
                <div class="card-body">
                    <p class="card-text">Individual registration </p>
                </div>
                <div class="card-footer">Cost NGN 3,500 <strike>NGN 5,000</strike></div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php echo site_url('/group'); ?>" class="card bg-warning text-white text-center">
                <!--  -->
                <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
                <i class="fa fa-5x fa-users text-center py-5"></i>
                <div class="card-header">Group Participant</div>
                <div class="card-body">
                    <p class="card-text">Individual registration</p>
                </div>
                <div class="card-footer">Cost NGN 3,000/ Participant</div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php echo site_url(); ?>" class="card bg-success text-white text-center">
                <!--  -->
                <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
                <i class="fa fa-5x fa-users text-center py-5"></i>
                <div class="card-header">Famliy</div>
                <div class="card-body">
                    <p class="card-text">Individual registration</p>
                </div>
                <div class="card-footer">Cost NGN 2,500 / Participant</div>
            </a>
        </div>

    </div>
</div> 